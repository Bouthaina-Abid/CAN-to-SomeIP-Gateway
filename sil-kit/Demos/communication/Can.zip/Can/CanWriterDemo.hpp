#pragma once

#include "silkit/services/orchestration/all.hpp"
#include "silkit/services/can/all.hpp"
#include "silkit/services/logging/ILogger.hpp"
#include "silkit/participant/IParticipant.hpp"

#include <chrono>
#include <thread>
#include <memory>

namespace SilKit {
namespace Demo {

void RunCanWriterDemo(SilKit::IParticipant* participant,
                      const std::string& canControllerName,
                      SilKit::Services::Orchestration::LifecycleService* lifecycleService,
                      uint32_t numberOfMessages,
                      uint32_t periodMs);

} // namespace Demo
} // namespace SilKit
