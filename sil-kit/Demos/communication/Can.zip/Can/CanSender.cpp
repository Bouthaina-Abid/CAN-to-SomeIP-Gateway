// SPDX-FileCopyrightText: 2024 Vector Informatik GmbH
//
// SPDX-License-Identifier: MIT

#include "ApplicationBase.hpp"
#include "CanDemoCommon.hpp"

class CanSender : public ApplicationBase
{
public:
    using ApplicationBase::ApplicationBase;

private:
    ICanController* _canController{nullptr};
    std::string _networkName = "CAN1";
    bool _printHex{false};
    bool _frameSent{false}; // Pour envoyer une seule fois

    void AddCommandLineArgs() override
    {
        GetCommandLineParser()->Add<CommandlineParser::Option>(
            "network", "N", _networkName, "-N, --network <name>",
            std::vector<std::string>{"Name of the CAN network to use.", "Defaults to '" + _networkName + "'."});

        GetCommandLineParser()->Add<CommandlineParser::Flag>("hex", "H", "-H, --hex",
                                                             std::vector<std::string>{"Print the CAN payload as hex."});
    }

    void EvaluateCommandLineArgs() override
    {
        _networkName = GetCommandLineParser()->Get<CommandlineParser::Option>("network").Value();
        _printHex = GetCommandLineParser()->Get<CommandlineParser::Flag>("hex").Value();
    }

    void CreateControllers() override
    {
        _canController = GetParticipant()->CreateCanController("CanController1", _networkName);

        _canController->AddFrameTransmitHandler([this](ICanController*, const CanFrameTransmitEvent& ack) {
            CanDemoCommon::FrameTransmitHandler(ack, GetLogger());
        });
        _canController->AddFrameHandler([this](ICanController*, const CanFrameEvent& frameEvent) {
            CanDemoCommon::FrameHandler(frameEvent, GetLogger(), _printHex);
        });
    }

    void InitControllers() override
    {
        _canController->SetBaudRate(10'000, 1'000'000, 2'000'000);
        _canController->Start();
    }

    void SendFrame()
    {
        uint8_t speedValue = 130;

        CanFrame canFrame{};
        canFrame.canId = 0x12;
        canFrame.flags = static_cast<CanFrameFlagMask>(CanFrameFlag::Fdf) 
                       | static_cast<CanFrameFlagMask>(CanFrameFlag::Brs);

        std::vector<uint8_t> data = {speedValue};
        canFrame.dataField = data;
        canFrame.dlc = static_cast<uint16_t>(data.size());

        std::stringstream ss;
        ss << "Sending CAN FD frame, canId=0x" << std::hex << canFrame.canId
           << ", speedValue=" << std::dec << static_cast<int>(speedValue);
        GetLogger()->Info(ss.str());

        _canController->SendFrame(canFrame);
    }

    void DoWorkSync(std::chrono::nanoseconds) override
{
    if (!_frameSent)
    {
        SendFrame();
        _frameSent = true;
        GetLifecycleService()->Stop("Frame sent, stopping CanSender");
    }
}

void DoWorkAsync() override
{
    if (!_frameSent)
    {
        SendFrame();
        _frameSent = true;
        GetLifecycleService()->Stop("Frame sent, stopping CanSender");
    }
}


};

int main(int argc, char** argv)
{
    Arguments args;
    args.participantName = "CanSender";
    args.duration = 0ms; // PAS périodique

    CanSender app{args};
    app.SetupCommandLineArgs(argc, argv, "SIL Kit Demo - Can: Send speedValue as CAN FD frame");
    return app.Run();
}
