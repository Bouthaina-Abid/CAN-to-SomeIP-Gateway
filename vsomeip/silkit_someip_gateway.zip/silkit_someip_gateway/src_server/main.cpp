#include "SomeIPServer.hpp"
#include <thread>


int main()
{
    SomeIPServer server;
    server.init();

    while (true)
        std::this_thread::sleep_for(std::chrono::seconds(1));

    return 0;
}
