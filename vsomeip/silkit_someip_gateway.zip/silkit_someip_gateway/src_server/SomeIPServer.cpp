#include "SomeIPServer.hpp"
#include <iostream>
#include <vector>
#include <iomanip>

#define SERVICE_ID  0x1234
#define INSTANCE_ID 0x5678
#define METHOD_ID   0x0421

SomeIPServer::SomeIPServer()
{
    // Name must match your server JSON "name" field (e.g. "GatewayService")
    app_ = vsomeip::runtime::get()->create_application("GatewayService");
}

void SomeIPServer::init()
{
    if (!app_->init())
    {
        std::cerr << "[SOME/IP SERVER] Initialization failed!" << std::endl;
        return;
    }

    // Register request handler BEFORE start()
    app_->register_message_handler(SERVICE_ID, INSTANCE_ID, METHOD_ID,
        std::bind(&SomeIPServer::on_request, this, std::placeholders::_1));

    app_->offer_service(SERVICE_ID, INSTANCE_ID);
    app_->start();

    std::cout << "[SOME/IP SERVER] Service started (GatewayService)" << std::endl;
}

void SomeIPServer::on_request(const std::shared_ptr<vsomeip::message>& request)
{
    auto payload = request->get_payload();
    if (!payload)
    {
        std::cout << "[SOME/IP SERVER] Received empty request" << std::endl;
        return;
    }
    auto data = payload->get_data();
    auto size = payload->get_length();

    std::cout << "[SOME/IP SERVER] Received request with payload: ";
    for (size_t i = 0; i < size; ++i)
        printf("%02X ", data[i]);
    std::cout << std::endl;

    // Build response (ACK). Example: echo payload back, or send a fixed ACK like {0x06}.
    // Here we send a simple ACK byte 0x06:
    std::vector<vsomeip::byte_t> ack_data = { 0x06 };

    // Create response using helper (preserves IDs/session)
    auto response = vsomeip::runtime::get()->create_response(request);
    auto ack_payload = vsomeip::runtime::get()->create_payload();
    ack_payload->set_data(ack_data);
    response->set_payload(ack_payload);

    app_->send(response);
    std::cout << "[SOME/IP SERVER] Sent ACK response" << std::endl;
}
