#pragma once

#include <vsomeip/vsomeip.hpp>
#include <memory>
#include <mutex>

class SomeIPServer
{
public:
    SomeIPServer();
    void init();

private:
    void on_request(const std::shared_ptr<vsomeip::message> &request);

    std::shared_ptr<vsomeip::application> app_;
    std::mutex send_mutex_;
};

