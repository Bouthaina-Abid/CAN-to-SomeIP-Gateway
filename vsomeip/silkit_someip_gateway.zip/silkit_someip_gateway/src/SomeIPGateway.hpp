#pragma once
#include <vsomeip/vsomeip.hpp>
#include <memory>
#include <mutex>
#include <vector>

class SomeIPGateway
{
public:
    SomeIPGateway();
    ~SomeIPGateway() = default;

    void init();
    void send_request(const uint8_t* data, size_t size);

    // optional handler if you want to receive responses
    void on_message(const std::shared_ptr<vsomeip::message>& response);

private:
    std::shared_ptr<vsomeip::application> app_;
    std::mutex send_mutex_;
};


